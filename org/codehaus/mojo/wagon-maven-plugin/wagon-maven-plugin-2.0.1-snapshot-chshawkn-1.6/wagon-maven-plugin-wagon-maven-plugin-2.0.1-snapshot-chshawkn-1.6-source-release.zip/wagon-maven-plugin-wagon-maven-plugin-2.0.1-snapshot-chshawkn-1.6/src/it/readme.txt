This directory contains a set of maven projects to integrated with shitty-maven-plugin for integration.
it is mainly server as examples.


To run each project individually you will need to pass in -Dversion=your.interested.wagon.plugin.version